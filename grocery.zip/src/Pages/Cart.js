import React from 'react';
import { FaTrash, FaPlus, FaMinus } from 'react-icons/fa';

import BillingDetails from '../components/BillingDetails';


const Cart = () => {





    return (
        // <main className="py-16">
        //     <div className="container 2xl:px-8 px-2 mx-auto">
        //         <h2 className="mb-8 text-xl font-bold">Shopping Cart</h2>
        //         <div className="cartListContainer">
        //             <div className="space-y-6">
        //                 {/* Cart Item */}
        //                 {
        //                     cart?.map(item =>
        //                         <div className="cartCard">
        //                             <div className="flex items-center col-span-6 space-x-6">
        //                                 {/* cart image */}
        //                                 <img className="w-40 h-40" src={item?.image} alt="product" />
        //                                 {/* cart item info */}
        //                                 <div className="space-y-2">
        //                                     <h4 className='fontbold' >{item?.title}</h4>
        //                                     <p>BDT <span >{item?.singlePrice}</span></p>
        //                                 </div>
        //                             </div>
        //                             <div className="flex items-center justify-center col-span-4 mt-4 space-x-8 md:mt-0">
        //                                 {/* amount buttons */}
        //                                 <div className="flex items-center space-x-4">
        //                                     <button >
        //                                         {/* <i className="text-lg fa-solid fa-plus" /> */}
        //                                         <FaPlus className="text-lg" ></FaPlus>
        //                                     </button>
        //                                     <span className="lws-cartQuantity">{item?.quantity}</span>
        //                                     <button >
        //                                         {/* <i className="text-lg fa-solid fa-minus" /> */}
        //                                         <FaMinus className="text-lg" ></FaMinus>
        //                                     </button>
        //                                 </div>
        //                                 {/* price */}
        //                                 <p className="text-lg font-bold">BDT <span >{item?.price}</span></p>
        //                             </div>
        //                             {/* delete button */}
        //                             <div className="flex items-center justify-center col-span-2 mt-4 md:justify-end md:mt-0">
        //                                 <button className="lws-removeFromCart">
        //                                     {/* <i className="text-lg text-red-400 fa-solid fa-trash" /> */}
        //                                     <FaTrash className="text-lg" ></FaTrash>
        //                                 </button>
        //                             </div>
        //                         </div>


        //                     )

        //                 }
        //                 {/* Cart Items Ends */}
        //             </div>
        //             {/* Bill Details */}
        //             <div>
        //                 <BillingDetails />
        //             </div>
        //         </div>
        //     </div>
        // </main>

        <div></div>
    );
};

export default Cart;